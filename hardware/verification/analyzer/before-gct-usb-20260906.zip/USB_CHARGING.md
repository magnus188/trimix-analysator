# USB charging compatibility — A2.1

The required circuit is now drawn on **sheet 10, USB_Input**. It supports
5 V charging through USB-A-to-C and USB-C-to-C cables when the panel socket
implements that circuit and the source/cable pass the checks below.
**The contents of the purchased two-wire panel socket remain unverified.**
The drawing is a requirement for that assembly, not evidence that its
manufacturer fitted the resistors.

## What was added

Inside the panel socket assembly, connect:

| Connection | Required part / destination |
|---|---|
| CC1, contact A5 | R901, 5.1 kΩ 1%, to GND |
| CC2, contact B5 | R902, 5.1 kΩ 1%, to GND |
| VBUS contacts | Positive wire to main-board J101 pin 1, USB_5V |
| Ground contacts | Return wire to main-board J101 pin 2, GND |

Keep CC1 and CC2 separate. Each needs its own resistor; neither is tied to
a switched supply or controlled by firmware. Exactly one Rd per CC pin is
required. If the socket already contains the correct resistors, those
existing parts fulfill R901/R902—do not add duplicates in parallel.

J901 uses a generic six-contact power-only symbol to explain the electrical
function. It is not a verified mechanical footprint or a complete pinout of
the purchased panel assembly. J901/R901/R902 are off the main PCB, so the
main-board connector and two-wire harness are retained.

A USB-C source detects these Rd resistors before providing VBUS. Two
independent resistors cover the reversible receptacle; they remain present
with no battery or host power. A compliant A-to-C cable already contains
the source-side Rp in its Type-C plug. Do not add Rp to this sink.
[TI sink-wiring guidance](https://e2e.ti.com/support/power-management-group/power-management/f/power-management-forum/1287225/bq24075t-charging-li-ion-battery-from-usb-c),
[TI BQ25185EVM circuit, Figure 4-1](https://www.ti.com/lit/ug/sluucs1/sluucs1.pdf)

If the sealed panel socket has neither the required resistors nor accessible
CC connections, **replace or modify the socket assembly**, possibly with a
small connector-side board. Adding resistors to VBUS/GND on the main PCB
cannot repair absent CC termination through its two-wire cable.

## Power limits

This is a dataless 5 V input. The BQ25895 data-detection pins remain separately
unconnected, selecting its nominal 500 mA input setting; its actual battery
charge current depends on available input power and system load. The 620 Ω
hardware ILIM resistor is a separate backup ceiling, not a precise 500 mA
limit. No USB PD contract or 1.5/3 A CC-current detection is implemented.
[TI BQ25895 floating-data-pin confirmation](https://e2e.ti.com/support/power-management-group/power-management/f/power-management-forum/784019/bq25895-bq25895-current-limit)

USB Type-C Release 2.5 §4.6.2.1 permits a dataless Power Sinking Device to
consume up to 500 mA with Default-current advertisement, subject to USB 2.0
inrush requirements. Sections 4.5.2.2.3 and 4.8.5 cover unpowered attachment;
Table 4-28 specifies Rd. This does not establish universal compatibility with
every old computer port, noncompliant cable or proprietary charger. Qualify
the charging adapters/power banks intended for use, including actual input
current tolerance, startup and inrush.
[USB-IF Type-C Release 2.5, March 2026](https://www.usb.org/sites/default/files/USB%20Type-C%202.5%20Release%20202603.zip)

A high-wattage USB-C PD charger can provide its default 5 V to a compliant
sink without a PD request. Its wattage label does not authorize this design
to draw higher current or request a higher voltage. Full device operation
plus charging can still exceed the available input power; battery assistance
or reduced charging is expected. The two cells remain 1S2P, 6800 mAh nominal.

## Physical acceptance checks — not yet performed

Use an unpowered connector-side breakout/test fixture or inspect the small
board inside the assembly to check CC wiring. Avoid probing live, closely
spaced USB-C contacts. Both CC-to-GND paths should contain their own 5.1 kΩ
resistor. With only these two resistors in circuit, CC1-to-CC2 measures about
10.2 kΩ through GND, not a short; other internal components can affect a
meter reading. The two outer power terminals alone cannot reveal both CC
connections.

Keep charge ARM J104 **open** for the initial VBUS checks. Inspect polarity,
then use the intended charger and a known-good cable. Measure at J101 while
checking source turn-on; a power meter/test fixture and controlled load are
needed for current, cable-drop and inrush checks. Do not connect the Guition's
own USB power during these tests.

| Test | Required observation | Status |
|---|---|---|
| A charger → A-to-C cable, C plug each way up | Correct-polarity nominal 5 V at J101 | Not tested |
| C charger → C-to-C cable, all four end-orientation combinations | Source enables nominal 5 V every time | Not tested |
| C-to-C with an electronically marked cable | Same attachment behavior | Not tested |
| Above tests with battery disconnected and host off | CC attachment still works; no firmware dependency | Not tested |
| Controlled load near the intended input limit | Voltage/current within the qualified source and charger limits; no repeated resets | Not tested |
| Plug-in/startup/inrush | Meets source and USB inrush constraints; no transient overvoltage | Not tested |
| Charge ARM enabled after cell/NTC qualification, host off | Stable charging from both adapter types; correct pack voltage/current/temperature | Not tested |

Do not close ARM until cell charging limits, holder protection, polarity and
the pack thermistor have been verified. A successful USB attachment test is
not a validation of the battery charging profile.

## Saved checks

The ten-page schematic passes KiCad ERC with zero errors and zero warnings.
The CLI netlist independently confirms two separate CC nets, each containing
only its socket contact and resistor; both resistor returns join GND. All
existing main-board pin-net memberships are preserved. Results and explicit
physical-test status are in `verification/analyzer/usb-compatibility.json`.
The existing 3D board remains a main-board placement study; the new panel-side
resistors do not belong among its PCB footprints.
